# moderation/

Server-side slash commands and moderation actions.

- `commands.py` - the parser (`/help /clear /roll /kick /mute /unmute /warn`), username matching, hierarchy checks,
  audit logging and the system messages that report each action in the chat.
- `__init__.py` - exports `run`, `COMMANDS`, `CommandError`.

To add a command: add it to `COMMANDS` (with the permission it needs from `../permissions.py`), then handle its name in `run()`.
Always check the permission and the role hierarchy on the server; the browser is never trusted.
