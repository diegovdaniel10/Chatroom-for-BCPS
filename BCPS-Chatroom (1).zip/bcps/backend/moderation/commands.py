"""Slash commands: /help /clear /roll /kick /mute /unmute /warn.

Rules shared by all moderation commands:
* the actor needs the matching permission (see permissions.py) in THIS server;
* you can only act on members strictly below your role, never yourself;
* actions are written to the audit log (IDs and action names only, no message text);
* results are posted as server-created "system" messages so users cannot forge them.
Usernames may contain spaces: type the name as is (/kick Sam Student), or in quotes
(/warn "Sam" Student is a new rule) when two names overlap.
"""

from __future__ import annotations

import secrets
import time
import uuid

import permissions as P
from security import clean_text


class CommandError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status, self.message = status, message


# name: (permission needed or None, usage, description)
COMMANDS = {
    "help": (None, "/help", "Show the commands you can use."),
    "clear": (None, "/clear", "Clear this channel on your own screen (nobody else is affected)."),
    "roll": (None, "/roll", "Roll a 6-sided die and show the result to everyone."),
    "kick": ("kick_members", "/kick <username>", "Remove a member from this server (they can rejoin if it is open)."),
    "mute": ("timeout_members", "/mute <username> [minutes]", "Stop a member from sending messages (default 10, max 1440 minutes)."),
    "unmute": ("timeout_members", "/unmute <username>", "End a mute early."),
    "warn": ("warn_members", "/warn <username> <reason>", "Give a member a formal warning shown in the chat."),
}


def help_text(role: str) -> str:
    lines = ["Commands you can use:"]
    for name, (perm, usage, desc) in COMMANDS.items():
        if perm is None or P.has_perm(role, perm):
            lines.append(f"{usage} - {desc}")
    if P.has_perm(role, "delete_messages"):
        lines.append("/clear all - Delete every message in this channel for everyone.")
    if any(P.has_perm(role, perm) for perm in ("kick_members", "timeout_members", "warn_members")):
        lines.append('Names with spaces work as typed; use quotes if two names overlap, e.g. "Sam" or "Sam Student".')
    return "\n".join(lines)


def split_target(app, server_id: str, rest: str) -> tuple[dict, str]:
    """Find the member named at the start of `rest`; return (member, text after the name)."""
    rest = rest.strip()
    if not rest:
        raise CommandError(400, "Add a username. Type /help for usage.")
    members = app.db.q("SELECT u.id,u.name,u.name_lower,ms.role FROM memberships ms "
                       "JOIN users u ON u.id=ms.user_id WHERE ms.server_id=?", (server_id,))
    hit, remainder = None, ""
    if rest.startswith('"'):
        end = rest.find('"', 1)
        if end == -1:
            raise CommandError(400, "Missing closing quote.")
        wanted = rest[1:end].strip().lower()
        hit = next((m for m in members if m["name_lower"] == wanted), None)
        remainder = rest[end + 1:].strip()
    else:
        text = rest[1:] if rest.startswith("@") else rest
        low = text.lower()
        for m in members:  # longest name that starts the text wins
            n = m["name_lower"]
            if (low == n or low.startswith(n + " ")) and (hit is None or len(n) > len(hit["name_lower"])):
                hit = m
        if hit:
            remainder = text[len(hit["name"]):].strip()
    if not hit:
        raise CommandError(404, 'No member with that name in this server. Use quotes for names with spaces, e.g. /kick "Sam Student".')
    return hit, remainder


def post_system(app, ch: dict, actor_id: str, kind: str, text: str) -> dict:
    mid = str(uuid.uuid4())
    app.db.x("INSERT INTO messages(id,channel_id,user_id,text,created_at,kind) VALUES(?,?,?,?,?,?)",
             (mid, ch["id"], actor_id, text, int(time.time() * 1000), kind))
    out = app.message_out(mid)
    app.hub.broadcast({"type": "message.new", "serverId": ch["server_id"], "channelId": ch["id"], "message": out},
                      ch["server_id"], ch["id"])
    return out


def _need_post(app, user: dict, ch: dict, member: dict) -> None:
    if not P.has_perm(member["role"], "send") or P.level(member["role"]) < ch["min_post"]:
        raise CommandError(403, "You can't post in this channel, so you can't use this command here.")
    left = member["timeout_until"] - time.time()
    if left > 0:
        raise CommandError(403, f"You are timed out for {int(left // 60) + 1} more minute(s).")
    problem = app.message_rate_allowed(user["id"], member["role"], "", check_dup=False)
    if problem:
        raise CommandError(429, problem)


def _check_target(actor: dict, user: dict, target: dict, verb: str) -> None:
    if target["id"] == user["id"]:
        raise CommandError(403, f"You can't {verb} yourself.")
    if not P.can_moderate(actor["role"], target["role"]):
        raise CommandError(403, f"You can't {verb} someone at or above your own role.")


def run(app, user: dict, ch: dict, member: dict, text: str) -> dict:
    """Execute a slash command. Returns a dict the API sends back to the sender."""
    if len(text) < 2 or text[1].isspace():
        raise CommandError(400, "Unknown command. Type /help to see what you can use.")
    parts = text[1:].split(None, 1)
    name = parts[0].lower() if parts else ""
    rest = parts[1].strip() if len(parts) > 1 else ""
    spec = COMMANDS.get(name)
    if not spec:
        raise CommandError(400, "Unknown command. Type /help to see what you can use.")
    perm = spec[0]
    if perm and not P.has_perm(member["role"], perm):
        raise CommandError(403, f"You don't have permission to use /{name}.")
    sid, role = ch["server_id"], member["role"]

    if name == "help":
        return {"private": help_text(role)}
    if name == "clear" and not rest:
        return {"action": "clear"}
    if name == "clear":
        if rest.lower() != "all":
            raise CommandError(400, "Usage: /clear   or   /clear all")
        if not P.has_perm(role, "delete_messages"):
            raise CommandError(403, "Only moderators can clear a channel for everyone.")
        _need_post(app, user, ch, member)
        # blank the text unless an open report still needs it for review
        app.db.x("UPDATE messages SET deleted=1, text='' WHERE channel_id=? AND deleted=0 AND id NOT IN "
                 "(SELECT message_id FROM reports WHERE status='open')", (ch["id"],))
        app.db.x("UPDATE messages SET deleted=1 WHERE channel_id=? AND deleted=0", (ch["id"],))
        app.audit(sid, user["id"], "channel_clear", None, f"#{ch['name']}")
        app.hub.broadcast({"type": "channel.clear", "serverId": sid, "channelId": ch["id"]}, sid, ch["id"])
        return {"message": post_system(app, ch, user["id"], "clear", f"🧹 {user['name']} cleared this channel.")}

    _need_post(app, user, ch, member)
    if name == "roll":
        return {"message": post_system(app, ch, user["id"], "roll", f"🎲 {user['name']} rolled a {secrets.randbelow(6) + 1}")}

    target, remainder = split_target(app, sid, rest)
    if name == "kick":
        _check_target(member, user, target, "kick")
        if remainder:
            raise CommandError(400, "Usage: /kick <username>")
        app.db.x("DELETE FROM memberships WHERE server_id=? AND user_id=?", (sid, target["id"]))
        app.audit(sid, user["id"], "kick", target["id"])
        out = post_system(app, ch, user["id"], "kick", f"👢 {target['name']} was removed from the server by {user['name']}.")
        event = {"type": "member.update", "serverId": sid, "userId": target["id"]}
        app.hub.broadcast(event, sid)
        app.hub.send_to_user(target["id"], event)  # the kicked user is no longer a member, so notify directly
        return {"message": out}
    if name in ("mute", "unmute"):
        _check_target(member, user, target, name)
        minutes = 0
        if name == "mute":
            minutes = 10
            if remainder:
                if not remainder.isdigit() or not 1 <= int(remainder) <= 1440:
                    raise CommandError(400, "Usage: /mute <username> [minutes 1-1440]")
                minutes = int(remainder)
        elif remainder:
            raise CommandError(400, "Usage: /unmute <username>")
        until = int(time.time()) + minutes * 60 if minutes else 0
        app.db.x("UPDATE memberships SET timeout_until=? WHERE server_id=? AND user_id=?", (until, sid, target["id"]))
        app.audit(sid, user["id"], "timeout" if minutes else "timeout_clear", target["id"], f"{minutes} min (command)" if minutes else "")
        text_out = (f"🔇 {target['name']} was muted for {minutes} minute(s) by {user['name']}." if minutes
                    else f"🔊 {target['name']} was unmuted by {user['name']}.")
        out = post_system(app, ch, user["id"], "mute", text_out)
        app.hub.broadcast({"type": "member.update", "serverId": sid, "userId": target["id"]}, sid)
        return {"message": out}
    if name == "warn":
        _check_target(member, user, target, "warn")
        reason = clean_text(remainder, 1, 200)
        if not reason or "\n" in reason:
            raise CommandError(400, "Usage: /warn <username> <reason> (reason: 1-200 characters).")
        app.db.x("INSERT INTO warnings(id,server_id,user_id,issued_by,reason,created_at) VALUES(?,?,?,?,?,?)",
                 (str(uuid.uuid4()), sid, target["id"], user["id"], reason, int(time.time() * 1000)))
        count = app.db.one("SELECT COUNT(*) AS n FROM warnings WHERE server_id=? AND user_id=?", (sid, target["id"]))["n"]
        app.audit(sid, user["id"], "warn", target["id"], f"warning #{count}")
        return {"message": post_system(app, ch, user["id"], "warn",
                                       f"⚠️ Warning #{count} for {target['name']} from {user['name']}: {reason}")}
    raise CommandError(400, "Unknown command.")
