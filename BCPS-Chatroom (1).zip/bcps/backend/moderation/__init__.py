"""Moderation package: slash-command parsing and moderation actions.

Everything here runs on the server. The browser only sends the typed text; it never decides
who is allowed to kick, mute or warn."""
from .commands import COMMANDS, CommandError, run  # noqa: F401
