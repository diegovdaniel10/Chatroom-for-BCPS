"""Optional browser test (needs: pip install playwright && playwright install chromium).
Run from the project root:  python3 tests/e2e_browser.py"""
import os
import subprocess
import sys
import tempfile
import time

from playwright.sync_api import sync_playwright

PORT, OWNER, PASSWORD = "3111", "Dana K", "e2e-test-passphrase"
env = dict(os.environ, PORT=PORT, OWNER_NAME=OWNER, OWNER_PASSWORD=PASSWORD,
           DATABASE_URL="sqlite:///" + tempfile.mkdtemp() + "/e2e.db")
srv = subprocess.Popen([sys.executable, "backend/server.py"], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.5)
URL, errs = f"http://127.0.0.1:{PORT}/", []
try:
    with sync_playwright() as p:
        b = p.chromium.launch()

        def page(w=1280, h=800):
            pg = b.new_context(viewport={"width": w, "height": h}).new_page()
            pg.on("pageerror", lambda e: errs.append(str(e)))
            return pg

        o = page()
        o.goto(URL)
        assert o.locator("text=owner claim code").count() == 0, "claim-code field should be gone"
        assert not o.locator("#owner-form").is_visible(), "owner form must be hidden by default"
        o.wait_for_selector("#login-form"); o.keyboard.press("Alt+Escape")
        assert o.locator("#owner-form").is_visible(), "Alt+Esc should open the owner form"
        o.fill("#owner-name", OWNER); o.fill("#owner-pass", "wrong"); o.click("#owner-form button[type=submit]")
        o.wait_for_selector("#owner-error:has-text('Invalid username or password')")
        o.fill("#owner-pass", PASSWORD); o.click("#owner-form button[type=submit]")
        o.wait_for_selector(".chan"); assert o.inner_text("#me-role").startswith("Owner")
        print("alt+esc owner login ok")

        s = page(); s.goto(URL); s.fill("#login-name", "Sam Student"); s.click("#login-form button[type=submit]"); s.wait_for_selector(".chan")
        s.fill("#msg-input", "/help"); s.press("#msg-input", "Enter")
        s.wait_for_selector(".sysmsg.private:has-text('/roll')"); assert s.locator(".sysmsg.private:has-text('/kick')").count() == 0
        s.fill("#msg-input", "/roll"); s.press("#msg-input", "Enter")
        o.wait_for_selector(".sysmsg.roll:has-text('Sam Student rolled a')", timeout=5000)
        s.fill("#msg-input", "/kick Dana K"); s.press("#msg-input", "Enter")
        s.wait_for_selector("#toast:has-text('permission')")
        o.fill("#msg-input", "/warn Sam Student please be kind"); o.press("#msg-input", "Enter")
        s.wait_for_selector(".sysmsg.warn:has-text('Warning #1 for Sam Student')", timeout=5000)
        o.fill("#msg-input", "/mute Sam Student 5"); o.press("#msg-input", "Enter")
        s.wait_for_selector("#me-role:has-text('timed out')", timeout=5000)
        assert s.is_disabled("#msg-input")
        o.fill("#msg-input", "/unmute Sam Student"); o.press("#msg-input", "Enter")
        s.wait_for_selector("#me-role:not(:has-text('timed out'))", timeout=5000)
        s.fill("#msg-input", "/clear"); s.press("#msg-input", "Enter")
        s.wait_for_selector(".empty"); assert s.locator(".msg, .sysmsg").count() == 0
        o.fill("#msg-input", "/kick Sam Student"); o.press("#msg-input", "Enter")
        o.wait_for_selector(".sysmsg.kick:has-text('Sam Student was removed')", timeout=5000)
        s.wait_for_selector("#rail .srv:not(.active), #modal", timeout=5000)
        o.screenshot(path="/tmp/cmds.png")
        print("commands ok")
        b.close()
finally:
    srv.terminate()
print("page errors:", errs)
