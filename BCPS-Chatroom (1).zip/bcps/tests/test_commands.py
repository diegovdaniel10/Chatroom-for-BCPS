import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_app import Base, WSClient  # noqa: E402


class CommandTests(Base):
    def cmd(self, client, text, channel="general"):
        return self.say(client, text, channel)

    def role_of(self, client):
        return self.app.membership(self.sid, client.user["id"])

    def test_help_lists_only_allowed_commands(self):
        s, d, _ = self.cmd(self.user(), "/help")
        self.assertEqual(s, 200)
        for c in ("/help", "/clear", "/roll"):
            self.assertIn(c, d["private"])
        for c in ("/kick", "/mute", "/warn"):
            self.assertNotIn(c, d["private"])
        _, d, _ = self.cmd(self.user("moderator"), "/help")
        for c in ("/kick", "/mute", "/warn", "/clear all"):
            self.assertIn(c, d["private"])
        _, d, _ = self.cmd(self.user("helper"), "/help")
        self.assertNotIn("/kick", d["private"])

    def test_help_is_private_not_stored(self):
        u = self.user()
        self.cmd(u, "/help")
        _, h, _ = u.req("GET", f"/api/channels/{self.ch['general']}/messages")
        self.assertFalse(any("Commands you can use" in m["text"] for m in h["messages"]))

    def test_clear_is_local_only(self):
        a, b = self.user(), self.user()
        self.say(a, "visible to all")
        s, d, _ = self.cmd(a, "/clear")
        self.assertEqual((s, d), (200, {"action": "clear"}))
        _, h, _ = b.req("GET", f"/api/channels/{self.ch['general']}/messages")
        self.assertIn("visible to all", [m["text"] for m in h["messages"]])
        self.assertEqual(self.cmd(a, "/clear all")[0], 403)

    def test_clear_all_moderator_only(self):
        mod, student = self.user("moderator"), self.user()
        self.say(student, "old stuff", "questions")
        s, d, _ = self.cmd(mod, "/clear all", "questions")
        self.assertEqual((s, d["message"]["kind"]), (201, "clear"))
        _, h, _ = student.req("GET", f"/api/channels/{self.ch['questions']}/messages")
        self.assertEqual([m["kind"] for m in h["messages"]], ["clear"])
        self.assertEqual(self.cmd(mod, "/clear everything")[0], 400)

    def test_roll(self):
        u = self.user()
        results = set()
        for _ in range(5):
            s, d, _ = self.cmd(u, "/roll")
            self.assertEqual(s, 201)
            self.assertEqual(d["message"]["kind"], "roll")
            n = int(d["message"]["text"].rsplit(" ", 1)[1])
            self.assertTrue(1 <= n <= 6)
            results.add(n)
        _, h, _ = self.user().req("GET", f"/api/channels/{self.ch['general']}/messages")
        self.assertTrue(any(m["kind"] == "roll" for m in h["messages"]))  # visible to everyone
        self.assertEqual(self.say(u, "/roll")[0], 201)  # repeating is fine
        self.assertEqual(self.cmd(u, "/rollx")[0], 400)

    def test_roll_blocked_where_user_cannot_post(self):
        self.assertEqual(self.cmd(self.user(), "/roll", "announcements")[0], 403)

    def test_unknown_and_bad_commands(self):
        u = self.user()
        for text in ("/nope", "/", "/ roll"):
            self.assertEqual(self.cmd(u, text)[0], 400, text)

    def test_moderation_commands_denied_for_non_moderators(self):
        victim = self.user()
        for role in ("student", "normie", "helper", "developer"):
            actor = self.user(role)
            for text in (f"/kick {victim.user['name']}", f"/mute {victim.user['name']}",
                         f"/warn {victim.user['name']} rude", f"/unmute {victim.user['name']}"):
                self.assertEqual(self.cmd(actor, text)[0], 403, (role, text))
        self.assertIsNotNone(self.app.membership(self.sid, victim.user["id"]))

    def test_kick(self):
        mod, victim, admin = self.user("moderator"), self.user(), self.user("admin")
        ws = WSClient(self.port, victim.cookie)
        try:
            s, d, _ = self.cmd(mod, f"/kick {victim.user['name']}")
            self.assertEqual((s, d["message"]["kind"]), (201, "kick"))
            self.assertIsNone(self.app.membership(self.sid, victim.user["id"]))
            self.assertEqual(victim.req("GET", f"/api/channels/{self.ch['general']}/messages")[0], 404)
            # the kicked user is told straight away
            seen = []
            end = time.time() + 2
            while time.time() < end and not any(e["type"] == "member.update" for e in seen):
                try:
                    e = ws.next_event(0.3)
                except OSError:
                    continue
                if e:
                    seen.append(e)
            self.assertTrue(any(e["type"] == "member.update" and e["userId"] == victim.user["id"] for e in seen))
        finally:
            ws.close()
        # open servers can be rejoined (kick is not a ban)
        discover = victim.req("GET", "/api/servers")[1]["discover"]
        self.assertIn("BCPS Hub", [x["name"] for x in discover])
        # hierarchy / self / unknown / owner
        self.assertEqual(self.cmd(mod, f"/kick {mod.user['name']}")[0], 403)
        self.assertEqual(self.cmd(mod, f"/kick {admin.user['name']}")[0], 403)
        self.assertEqual(self.cmd(mod, f"/kick {self.owner.user['name']}")[0], 403)
        self.assertEqual(self.cmd(mod, "/kick Nobody Here")[0], 404)
        self.assertEqual(self.cmd(mod, "/kick")[0], 400)
        self.assertEqual(self.cmd(admin, f"/kick {self.user('moderator').user['name']}")[0], 201)

    def test_mute_and_unmute(self):
        mod, victim = self.user("moderator"), self.user()
        s, d, _ = self.cmd(mod, f"/mute {victim.user['name']}")
        self.assertEqual((s, d["message"]["kind"]), (201, "mute"))
        self.assertIn("10 minute", d["message"]["text"])
        self.assertGreater(self.role_of(victim)["timeout_until"], time.time() + 500)
        s, d, _ = self.say(victim, "can I talk")
        self.assertEqual(s, 403)
        self.assertEqual(self.cmd(victim, "/roll")[0], 403)  # commands are blocked while muted too
        self.assertEqual(self.cmd(mod, f"/mute {victim.user['name']} 30")[0], 201)
        self.assertGreater(self.role_of(victim)["timeout_until"], time.time() + 1700)
        for bad in ("0", "1441", "abc", "-5"):
            self.assertEqual(self.cmd(mod, f"/mute {victim.user['name']} {bad}")[0], 400, bad)
        self.assertEqual(self.cmd(mod, f"/unmute {victim.user['name']}")[0], 201)
        self.assertEqual(self.say(victim, "back again")[0], 201)
        self.assertEqual(self.cmd(mod, f"/mute {mod.user['name']}")[0], 403)
        self.assertEqual(self.cmd(mod, f"/mute {self.user('admin').user['name']}")[0], 403)

    def test_warn(self):
        mod, victim = self.user("moderator"), self.user()
        s, d, _ = self.cmd(mod, f"/warn {victim.user['name']} please be kind")
        self.assertEqual((s, d["message"]["kind"]), (201, "warn"))
        self.assertIn("Warning #1", d["message"]["text"])
        self.assertIn("please be kind", d["message"]["text"])
        _, h, _ = victim.req("GET", f"/api/channels/{self.ch['general']}/messages")  # shown in the feed
        self.assertTrue(any(m["kind"] == "warn" and "please be kind" in m["text"] for m in h["messages"]))
        d2 = self.cmd(mod, f"/warn {victim.user['name']} second one")[1]
        self.assertIn("Warning #2", d2["message"]["text"])
        self.assertEqual(self.cmd(mod, f"/warn {victim.user['name']}")[0], 400)           # reason required
        self.assertEqual(self.cmd(mod, f"/warn {victim.user['name']} " + "x" * 201)[0], 400)
        self.assertEqual(self.cmd(mod, f"/warn {mod.user['name']} nope")[0], 403)
        self.assertEqual(self.cmd(mod, f"/warn {self.owner.user['name']} nope")[0], 403)
        self.assertEqual(self.app.db.one("SELECT COUNT(*) AS n FROM warnings WHERE user_id=?", (victim.user["id"],))["n"], 2)

    def test_names_with_spaces_and_quotes(self):
        mod = self.user("moderator")
        a = self.app.db  # create two overlapping names: "Sam" and "Sam Student"
        from test_app import Client
        sam = Client(self.port).login("Sam")
        samstud = Client(self.port).login("Sam Student")
        s, d, _ = self.cmd(mod, '/warn "Sam" Student is a rule')
        self.assertEqual(s, 201)
        self.assertIn("Warning #1 for Sam from", d["message"]["text"])
        self.assertIn("Student is a rule", d["message"]["text"])
        s, d, _ = self.cmd(mod, "/warn Sam Student too loud")  # longest name wins
        self.assertIn("for Sam Student from", d["message"]["text"])
        self.assertEqual(self.cmd(mod, '/warn "Sam Student')[0], 400)
        self.assertEqual(self.cmd(mod, f"/warn @{sam.user['name']} hey")[0], 201)
        self.assertEqual(self.cmd(mod, '/kick "Sam" extra words')[0], 400)

    def test_system_messages_cannot_be_forged_edited_or_reported(self):
        mod, u = self.user("moderator"), self.user()
        mid = self.cmd(u, "/roll")[1]["message"]["id"]
        self.assertEqual(u.req("PATCH", f"/api/messages/{mid}", {"text": "🎲 rolled a 6"})[0], 403)
        self.assertEqual(mod.req("POST", f"/api/messages/{mid}/report", {"reason": "spam"})[0], 400)
        self.assertEqual(mod.req("POST", f"/api/messages/{mid}/reactions", {"emoji": "👍"})[0], 400)
        # a normal message that merely looks like a system line stays kind=user
        d = self.say(u, "🎲 Someone rolled a 6")[1]["message"]
        self.assertEqual(d["kind"], "user")

    def test_actions_are_audited_without_message_text(self):
        mod, victim = self.user("moderator"), self.user()
        self.cmd(mod, f"/warn {victim.user['name']} secret reason text")
        self.cmd(mod, f"/mute {victim.user['name']} 5")
        sa = self.user("super_admin")
        _, d, _ = sa.req("GET", f"/api/servers/{self.sid}/audit")
        actions = [e["action"] for e in d["entries"]]
        self.assertIn("warn", actions)
        self.assertIn("timeout", actions)
        self.assertNotIn("secret reason text", str(d))

    def test_commands_rate_limited(self):
        u = self.user()
        codes = [self.cmd(u, "/roll")[0] for _ in range(9)]
        self.assertEqual(codes[:6], [201] * 6)
        self.assertIn(429, codes[6:])


if __name__ == "__main__":
    unittest.main(verbosity=2)
